import React from "react"

const list = ({setValueBtn}) => {
    setValueBtn(2)
    return <>
        <h1>List</h1>
    </>
  
}

export default list