import React from "react"

const notFound = () => {
    return <>
        <h1>404</h1>
    </>
  
}

export default notFound