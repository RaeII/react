import React from "react"

const alerts = ({setValueBtn}) => {
    setValueBtn(1)
    return <>
        <h1>Alerts</h1>
    </>
  
}

export default alerts