import React from "react"

const home = ({setValueBtn}) => {
    setValueBtn(0)
    return <>
        <h1>Home</h1>
    </>
  
}

export default home
